// 추후 검색 폼과 결과 테이블 추가 예정.
export default function CvePage() {
  return <div>CVE search coming soon</div>
}
