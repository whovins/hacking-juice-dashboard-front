// 추후 IOC 검색/상세/연관 이벤트 섹션 추가 예정.
export default function IocExplorerPage() {
  return <div>IOC explorer coming soon</div>
}
