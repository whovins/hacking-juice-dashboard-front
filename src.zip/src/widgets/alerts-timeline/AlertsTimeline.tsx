// 알림 타임라인 위젯 자리표시자. Plotly로 대체 가능.
export default function AlertsTimeline() {
  return <div>Alerts timeline coming soon</div>
}
