export type Ioc = {
  ioc: string
  ioc_type: string
  first_seen?: string
  last_seen?: string
  score?: number
}
