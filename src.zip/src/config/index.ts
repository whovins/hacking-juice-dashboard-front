export const cfg = {
  apiBase: import.meta.env.VITE_API_BASE_URL,
  wsBase: import.meta.env.VITE_WS_BASE_URL,
}
