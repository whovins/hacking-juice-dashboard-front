export const nf = (n: number) => new Intl.NumberFormat().format(n)
