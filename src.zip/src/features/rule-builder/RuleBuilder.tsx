// 규칙 작성 폼 자리표시자.
export default function RuleBuilder() {
  return <div>Rule builder coming soon</div>
}
