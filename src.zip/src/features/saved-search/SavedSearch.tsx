// 저장된 검색 관리 자리표시자.
export default function SavedSearch() {
  return <div>Saved searches coming soon</div>
}
